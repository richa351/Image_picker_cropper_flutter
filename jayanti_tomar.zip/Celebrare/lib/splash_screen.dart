import 'package:celebrare/Home.dart';
import 'package:flutter/material.dart';
import 'dart:async';
class Splash extends StatefulWidget {
  const Splash({super.key});

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState()
  {
    super.initState();
    _navigatetohome();
  }
  _navigatetohome() async{
    await Future.delayed(Duration(seconds: 1),(){});
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> Home()));
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Container(

          child: Image.asset('images/icon1.png'),
        ),
      ),
    );
  }
}

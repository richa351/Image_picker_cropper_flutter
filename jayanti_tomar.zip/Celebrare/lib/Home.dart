

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'main.dart';
import 'dart:io';
import 'package:image_cropper/image_cropper.dart';
import 'package:image/image.dart' as img;

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  File ? _selectedImage;
  Future _pickImageGallery() async{
    final returnedImage= await ImagePicker().pickImage(source: ImageSource.gallery).then((value){
      if(value!=null)
        {
          _cropImage(File(value.path));
        }
    });
    if(returnedImage==null)
      return;
    setState(() {
      _selectedImage= File(returnedImage!.path);
    });
  }
  _cropImage(File imgFile) async{
    final croppedFile = await ImageCropper().cropImage(
        sourcePath: imgFile.path,
        aspectRatioPresets: Platform.isAndroid
            ? [
          CropAspectRatioPreset.original,
          /*CropAspectRatioPreset.square,
         CropAspectRatioPreset.ratio3x2,
          CropAspectRatioPreset.ratio4x3,

          CropAspectRatioPreset.ratio16x9*/
        ] : [
          CropAspectRatioPreset.original,
          //CropAspectRatioPreset.square,
          /*CropAspectRatioPreset.ratio3x2,
          CropAspectRatioPreset.ratio4x3,
          CropAspectRatioPreset.ratio5x3,
          CropAspectRatioPreset.ratio5x4,
          CropAspectRatioPreset.ratio7x5,
          CropAspectRatioPreset.ratio16x9*/
        ],
        uiSettings: [AndroidUiSettings(
           // toolbarTitle: "Image Cropper",
            toolbarColor: Colors.grey,
            toolbarWidgetColor: Colors.white,
            initAspectRatio: CropAspectRatioPreset.original,
            lockAspectRatio: false,
            hideBottomControls:false),
          /*IOSUiSettings(
            title: "Image Cropper",
          )*/

        ]);
    if (croppedFile != null) {

      imageCache.clear();
      setState(() {
        _selectedImage = File(croppedFile.path);
      });
      // reload();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Image / Icon'),
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.keyboard_arrow_left_sharp,
            size: 50.0,), onPressed: () {
          SystemNavigator.pop();
          //Navigator.pop(context);
        },
        ),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
      ),
      body: Column(
        children: [
          Container(
            margin:EdgeInsets.all(10.0),
            height: 120,
            decoration: BoxDecoration(
                border: Border.all(
                  color: Colors.grey, // Border color
                  width: 1.0,           // Border width
                ),
                borderRadius: BorderRadius.circular(12)),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(15.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,

                  children: [
                    Text('Upload Image'),
                    TextButton(onPressed: (){
                      _pickImageGallery();
                    },child: Text('Choose from Device',
                      style: TextStyle(
                        fontWeight: FontWeight.normal,
                        fontFamily:'Times New Roman',
                      ),),
                      style: TextButton.styleFrom(
                        padding: EdgeInsets.all(10.0),
                        backgroundColor: Colors.teal[700],
                        foregroundColor: Colors.white,
                      ),),

                  ],),),
            ),

          ),
          const SizedBox(height: 20.0,),

          _selectedImage != null ? Image.file(_selectedImage!,height: 600, // Adjust the height as needed
            width: 600,): SizedBox(),
        ],
      ),
    );
  }
}

package com.example.celebrare

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
